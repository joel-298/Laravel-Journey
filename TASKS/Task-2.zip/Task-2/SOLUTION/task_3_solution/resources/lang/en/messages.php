<?php

return [
    'home_title' => 'Welcome to Our Website',
    'about_title' => 'About Us',
    'services_title' => 'Our Services',
    'departments_title' => 'Our Departments',
    'doctors_title' => 'Our Doctors',
    'contact_title' => 'Contact Us',
    // Add other translations as needed
];
