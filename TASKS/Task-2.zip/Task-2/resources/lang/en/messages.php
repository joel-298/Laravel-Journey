<?php
return [
    'home_title' => 'Welcome to Our Website',
    'about_title' => 'About Us',
    'services_title' => 'Our Services',
    'departments_title' => 'Departments',
    'doctors_title' => 'Our Doctors',
    'contact_title' => 'Contact Us',
    'appointment_title' => 'Appointment',
    'dropdown_title' => 'Users',
];
?>